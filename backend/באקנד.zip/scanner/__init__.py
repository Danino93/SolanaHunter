"""
Scanner Module
Token discovery and scanning
"""
