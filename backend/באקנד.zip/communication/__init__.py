"""
Communication module (Telegram, notifications, command handlers)
"""

