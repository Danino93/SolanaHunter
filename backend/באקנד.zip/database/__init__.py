"""
Database Module - Supabase Integration

📋 מה המודול הזה עושה:
-------------------
מודול לניהול חיבור ושמירה ל-Supabase.
"""
