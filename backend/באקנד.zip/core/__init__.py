"""
SolanaHunter Core Module
Core business logic and shared components
"""

__version__ = "1.0.0"
