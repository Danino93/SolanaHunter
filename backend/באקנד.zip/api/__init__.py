"""
API Module - FastAPI REST API for Dashboard
"""
