"""
API Routes - All API endpoints
"""
