"""
Utilities Module
Helper functions and utilities
"""
